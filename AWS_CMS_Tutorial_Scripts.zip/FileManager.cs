using System.Collections;
using UnityEngine.UI;
using System.IO;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using UnityEngine;
using Debug = UnityEngine.Debug;
using TMPro;


public class FileManager : MonoBehaviour
{
 

    public void SaveTextureFlagToFile(string pTextureName)
    {
        if (File.Exists(GameManager.textureFlagPath))
        {
            File.Delete(GameManager.textureFlagPath);
        }

        File.WriteAllText(GameManager.textureFlagPath, pTextureName);


        string text = System.IO.File.ReadAllText(GameManager.textureFlagPath);
        Debug.Log(text);
    }


    public void AccessCoroutineCallBatchFile()
    {
        StartCoroutine(CallBatchFile());
    }


     IEnumerator CallBatchFile()
    {
        yield return new WaitForSeconds(.2f);
        Debug.Log("CallBatchFile now");
 
        RebuildAddressablePrefabAndGroupViaBatchFileCall();
    }

     
    void RebuildAddressablePrefabAndGroupViaBatchFileCall()
    {
        ProcessStartInfo psi = new ProcessStartInfo(GameManager.batchFilepath);

        psi.WindowStyle = ProcessWindowStyle.Hidden;

        Process.Start(psi);
    }

     












}