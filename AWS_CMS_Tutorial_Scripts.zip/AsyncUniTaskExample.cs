using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;


public class AsyncUniTaskExample : MonoBehaviour
{
    
    
    private CancellationTokenSource _cancellationTokenSource;

    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            GameManager.hashChanged = true;
        }
    }

    public void Start()
    {
        _cancellationTokenSource = new CancellationTokenSource();

        WaitForHashToChange();
    }

    public async void WaitForHashToChange()
    {
        Debug.Log("hashchanged is = " + GameManager.hashChanged + "  --- WAIT to run aws commands ");
        try
        {
            await UniTask.WaitUntil((() => GameManager.hashChanged), cancellationToken: _cancellationTokenSource.Token);
        }
        catch (OperationCanceledException e)
        {
            Debug.Log(e.Message);
        }

        if (_cancellationTokenSource.IsCancellationRequested)
        {
            Debug.Log("Task is canceled");
            return;
        }

        if (GameManager.hashChanged==false)
        {
            Debug.Log("hashchanged  is false  --- WAIT to run aws commands");
        }
        else if  (GameManager.hashChanged==true)
        {
            Debug.Log("hashchanged  is True  --- RUN aws commands");
            _cancellationTokenSource.Cancel();
        }
         
    }
  

    private void OnDisable()
    {
        _cancellationTokenSource.Cancel();
        Debug.Log("OnDisable: Task is canceled");
    }
    
    
}
