using System;
using System.Collections;
using System.IO;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{ 

    GameObject FileManager;
    
    void Awake()
    {
        FileManager = GameObject.FindGameObjectWithTag("FileManager");
    }
      
    public TMP_Text displayMessage;

    public Button ButtonVanilla = null;
    public Button ButtonAlmond = null;
    public Button ButtonOrange = null;

    public GameObject DeleteAllObjectsButton;
    public GameObject UploadAllObjectsButton;

    bool enableAWSOpButtons = false;



    void Start()
    {
        ButtonVanilla.onClick.AddListener(() => { ButtonChangeToVanillaOnClick(); });
        ButtonAlmond.onClick.AddListener(() => { ButtonChangeToAlmondOnClick(); });
        ButtonOrange.onClick.AddListener(() => { ButtonChangeToOrangeOnClick(); });
    }

    public void ToggleAWSUtilOpButtons()
    {
        enableAWSOpButtons = !enableAWSOpButtons;
        DeleteAllObjectsButton.SetActive(enableAWSOpButtons);
        UploadAllObjectsButton.SetActive(enableAWSOpButtons);
    }

    public void ManageDisplayMessage(string message)
    {
        displayMessage.text = message;
    }


    public void ManageDisplayMessage(string message, float delay)
    {
        StartCoroutine(DelayMessage(message, delay));

    }

    IEnumerator DelayMessage(string message, float delay)
    {
        yield return new WaitForSeconds(delay);
        displayMessage.text = message;
    }

    public void BlinkText()
    {
        displayMessage.GetComponent<Animator>().SetTrigger("Blink");      
    }


    //BUTTON HANDLERS --------------------------------------------------------------------------
    //ButtonChangeToVanillaOnClick   BUTTON HANDLER
    public void ButtonChangeToVanillaOnClick()
    {
        //Save the name of the texture that needs to be loaded to a text file in C:\Temp
        FileManager.GetComponent<FileManager>().SaveTextureFlagToFile("Vanilla");
        FileManager.GetComponent<FileManager>().AccessCoroutineCallBatchFile();
        ManageDisplayMessage("Rebuilding content for Vanilla...");
        BlinkText();
    }
    //------------------------------


    //ButtonChangeToAlmondOnClick   BUTTON HANDLER
    public void ButtonChangeToAlmondOnClick()
    {
        //Save the name of the texture that needs to be loaded to a text file in C:\Temp
        FileManager.GetComponent<FileManager>().SaveTextureFlagToFile("Almond");
        FileManager.GetComponent<FileManager>().AccessCoroutineCallBatchFile();
        ManageDisplayMessage("Rebuilding content for Almond...");
        BlinkText();
    }
    //------------------------------


    //ButtonChangeToOrangeOnClick   BUTTON HANDLER
    public void ButtonChangeToOrangeOnClick()
    {
        //Save the name of the texture that needs to be loaded to a text file in C:\Temp
        FileManager.GetComponent<FileManager>().SaveTextureFlagToFile("Orange");
        FileManager.GetComponent<FileManager>().AccessCoroutineCallBatchFile();
        ManageDisplayMessage("Rebuilding content for Orange...");
        BlinkText();
    }
    //------------------------------


}