using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.Runtime;
using System.IO;
using System;
using Amazon.S3.Util;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Amazon;
using Cysharp.Threading.Tasks;
using TMPro;
using Debug = UnityEngine.Debug;


public class AWSManager : MonoBehaviour
{

    public const string BUCKET_NAME = "place your aws s3 bucket name here";
    public static string filepath = GameManager.awsServerDataFilePathIOS;

    private static AmazonS3Client s3Client;
    private BasicAWSCredentials awsCredentials;

    GameObject UIManager;


    public Button DeleteAllObjectsButton = null;
    public Button UploadAllObjectsButton = null;


    void Awake()
    {
        UIManager = GameObject.FindGameObjectWithTag("UIManager");
    }

    void Start()
    {

        ActivateWaitForHashToChange();

        awsCredentials = new BasicAWSCredentials("place your aws access key id here", "place your aws secret access key here");
        s3Client = new AmazonS3Client(awsCredentials, RegionEndpoint.USEast1);

        DeleteAllObjectsButton.onClick.AddListener(() => { DeleteAllObjects(); });
        UploadAllObjectsButton.onClick.AddListener(() => { UploadAllObjects(); });

    }


    void ActivateWaitForHashToChange()
    {
        GameManager._hashChangeCancellationTokenSource = new CancellationTokenSource();
        WaitForHashToChange();
    }



    public async void WaitForHashToChange()
    {
        Debug.Log("Initial message:  hashchanged is = " + GameManager.hashChanged + "  --- WAIT to run aws commands ");

        try
        {
            await UniTask.WaitUntil((() => GameManager.hashChanged == true), cancellationToken: GameManager._hashChangeCancellationTokenSource.Token);
        }
        catch (OperationCanceledException e)
        {
            Debug.Log(e.Message);
        }

        if (GameManager.hashChanged == false)//this happens only if the operation was cancelled 
        {
            Debug.Log("hashchanged  is false  --- WAIT to run aws commands");
        }
        else if (GameManager.hashChanged == true)
        {
            Debug.Log("hashchanged  is True  --- RUN aws commands");
            UIManager.GetComponent<UIManager>().BlinkText();//Stop Blinking
            UIManager.GetComponent<UIManager>().ManageDisplayMessage("App content has been rebuilt and cloud content has been updated!");

            GameManager.hashChanged = false;

            Task.Run(() => DeleteAllObjectsAsync(s3Client)).Wait();
            Debug.Log("objects deleted");
            await UploadAllObjectsAsync(s3Client);

            GameManager._hashChangeCancellationTokenSource.Cancel();
        }

        if (GameManager._hashChangeCancellationTokenSource.IsCancellationRequested)
        {
            Debug.Log("Task was canceled and is now reset");
            ActivateWaitForHashToChange();
            UIManager.GetComponent<UIManager>().ManageDisplayMessage("", 6.0f); //Delay clearing the text display field for 3 seconds so the previous message can be read

            return;
        }

    }




    #region  -------------------------------------- BUTTON HANDLERS  ------------------------------------------------------------------------------------------------------------------------

    //GetBucketList BUTTON HANDLER
    public async void GetBucketList()
    {
        var listResponse = await MyListBucketsAsync(s3Client);

        //PRINTING DATA
        Debug.Log(listResponse.Buckets.Count);
        foreach (S3Bucket b in listResponse.Buckets)
        {
            Debug.Log(b.BucketName + b.CreationDate);
        }
    }



    //GetObjectList BUTTON HANDLER
    public async void GetObjectList()
    {
        await ListingObjectsAsync(s3Client);
    }



    //DeleteObject BUTTON HANDLER
    public async void DeleteObject()
    {
        string testObjectName = "StandaloneWindows/readme.txt";


        await DeleteObjectAsync(s3Client, testObjectName);
    }



    //DeleteAllObjects BUTTON HANDLER
    public async void DeleteAllObjects()
    {
        await DeleteAllObjectsAsync(s3Client);
    }



    //UploadAllObjects BUTTON HANDLER
    public async void UploadAllObjects()
    {
        await UploadAllObjectsAsync(s3Client);
    }

    #endregion     -------------------------------------- BUTTON HANDLERS  ------------------------------------------------------------------------------------------------------------------------


    #region -------------------------------------- AWS API CALLS  ------------------------------------------------------------------------------------------------------------------------

    // GetBucketList
    private static async Task<ListBucketsResponse> MyListBucketsAsync(IAmazonS3 s3Client)
    {
        return await s3Client.ListBucketsAsync();
    }

    // GetObjectList
    public static async Task ListingObjectsAsync(IAmazonS3 client)
    {
        try
        {
            ListObjectsV2Request request = new ListObjectsV2Request();
            request.BucketName = BUCKET_NAME;

            var response = new ListObjectsV2Response();

            do
            {
                response = await client.ListObjectsV2Async(request);

                response.S3Objects
                    .ForEach(obj => Debug.Log($"{obj.Key,-35}{obj.LastModified.ToShortDateString(),10}{obj.Size,10}"));

                // If the response is truncated, set the request ContinuationToken  from the NextContinuationToken property of the response.
                request.ContinuationToken = response.NextContinuationToken;
            } while (response.IsTruncated);
        }
        catch (AmazonS3Exception ex)
        {
            Debug.Log($"Error encountered on server. Message:'{ex.Message}' getting list of objects.");
        }
    }


    // DeleteObject
    public static async Task DeleteObjectAsync(IAmazonS3 client, string keyName)
    {
        try
        {
            Debug.Log("deleting " + keyName);

            // Create a DeleteObject request
            DeleteObjectRequest request = new DeleteObjectRequest
            {
                BucketName = BUCKET_NAME,
                Key = keyName
            };

            // Issue request
            await client.DeleteObjectAsync(request);
        }
        catch (AmazonS3Exception ex)
        {
            Debug.Log($"Error: {ex.Message}");
        }
    }


    // DeleteAllObjects
    public static async Task DeleteAllObjectsAsync(IAmazonS3 client)
    {
        try
        {
            ListObjectsV2Request request = new ListObjectsV2Request();
            request.BucketName = BUCKET_NAME;

            var response = new ListObjectsV2Response();

            do
            {
                response = await client.ListObjectsV2Async(request);

                var responseObjects = response.S3Objects;
                foreach (var responseObject in responseObjects)
                {
                    if (responseObject.Key != "IOS/keep.txt")
                    {
                        Debug.Log(responseObject.Key + "  kill this one");
                        await DeleteObjectAsync(s3Client, responseObject.Key);
                    }
                }


                // If the response is truncated, set the request ContinuationToken  from the NextContinuationToken property of the response.
                request.ContinuationToken = response.NextContinuationToken;
            } while (response.IsTruncated);
        }
        catch (AmazonS3Exception ex)
        {
            Debug.Log($"Error encountered on server. Message:'{ex.Message}' getting list of objects.");
        }
    }


    // UploadAllObjects
    public static async Task UploadAllObjectsAsync(IAmazonS3 client)
    {
        Debug.Log(client + " uploading");

        try
        {
            int filePathStringLength = filepath.Length;
            string[] files = Directory.GetFiles(filepath);

            foreach (string fileName in files)
            {
                string trimmedFileName = fileName.Substring(filePathStringLength);
                var stream = new FileStream(filepath + trimmedFileName, FileMode.Open, FileAccess.Read, FileShare.Read);

                var putRequest = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    InputStream = stream,
                    Key = "IOS/" + trimmedFileName,
                    CannedACL = S3CannedACL.PublicRead
                };

                PutObjectResponse response = await client.PutObjectAsync(putRequest);
            }
        }

        catch (AmazonS3Exception e)
        {
            Console.WriteLine($"Error: {e.Message}");
        }
    }


    #endregion  --------------------------------------  AWS API CALLS ------------------------------------------------------------------------------------------------------------------------


}